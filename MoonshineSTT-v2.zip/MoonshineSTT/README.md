# كلام لنص (MoonshineSTT) — النسخة 2

تطبيق أندرويد بيحوّل الكلام العربي لنص **أوفلاين** بموديل Moonshine، بشكل مغربي حديث
(زليج متحرك، نجمة خاتم بتلف، كرة تسجيل بتتنفس مع صوتك، ثيم ليل ماجوريل / رمل مراكشي).

## أسهل طريقة تطلع APK (من غير Android Studio)
1. اعمل Repository جديد على GitHub.
2. ارفع **ملف الـ ZIP زي ما هو** (Add file ← Upload files).
3. اعمل ملف جديد (Add file ← Create new file) باسم `.github/workflows/build.yml`
   والصق جواه محتوى `build.yml` المرفق.
4. تبويب **Actions** ← **Build APK** ← **Run workflow**. استنى 5-10 دقايق.
5. نزّل **MoonshineSTT-apk** من Artifacts، وفكّه، وثبّت `app-debug.apk`.

الـ workflow بيفك الـ ZIP لوحده أثناء البناء وبينزّل الموديل العربي ويبني.

## من Android Studio
1. `pip install moonshine-voice` ثم `python -m moonshine_voice.download --language ar`
2. انسخ فولدر الموديل جوه `app/src/main/assets/` وسمّيه `base-ar`
3. افتح المشروع وشغّله.

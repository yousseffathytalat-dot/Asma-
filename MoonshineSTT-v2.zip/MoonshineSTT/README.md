# كلام لنص (MoonshineSTT) — النسخة 2

تطبيق أندرويد بيحوّل الكلام العربي لنص **أوفلاين** بموديل Whisper، بشكل مغربي حديث
(زليج متحرك، نجمة خاتم بتلف، كرة تسجيل بتتنفس مع صوتك، ثيم ليل ماجوريل / رمل مراكشي).

## أسهل طريقة تطلع APK (من غير Android Studio)
1. اعمل Repository جديد على GitHub.
2. ارفع **ملف الـ ZIP زي ما هو** (Add file ← Upload files).
3. اعمل ملف جديد (Add file ← Create new file) باسم `.github/workflows/build.yml`
   والصق جواه محتوى `build.yml` المرفق.
4. تبويب **Actions** ← **Build APK** ← **Run workflow**. استنى 5-10 دقايق.
5. نزّل **MoonshineSTT-apk** من Artifacts، وفكّه، وثبّت `app-debug.apk`.

الـ workflow بيفك الـ ZIP لوحده أثناء البناء وبينزّل الموديل العربي ويبني.

## ملاحظات النسخة 1.3
- بقى بيستخدم **Whisper medium** (int8) بمحرك sherpa-onnx بدل Moonshine.
- أول تشغيل بينزّل الموديل (حوالي 930 ميجا) من Hugging Face مرة واحدة، وبعدها بيشتغل أوفلاين.
- محتاج موبايل فيه رام 6 جيجا أو أكتر.

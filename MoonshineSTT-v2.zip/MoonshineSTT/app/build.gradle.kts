plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.moknight.speech2text"
    compileSdk = 34
    defaultConfig { applicationId = "com.moknight.speech2text"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    androidResources { noCompress += listOf("ort", "onnx", "bin", "json") }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("ai.moonshine:moonshine-voice:0.1.5")
}

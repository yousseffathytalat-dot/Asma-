package com.moknight.speech2text

import android.content.Context
import com.k2fsa.sherpa.onnx.FeatureConfig
import com.k2fsa.sherpa.onnx.OfflineModelConfig
import com.k2fsa.sherpa.onnx.OfflineRecognizer
import com.k2fsa.sherpa.onnx.OfflineRecognizerConfig
import com.k2fsa.sherpa.onnx.OfflineWhisperModelConfig
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.sqrt

/** Whisper medium (int8) على الجهاز بمحرك sherpa-onnx. الموديل بيتنزّل مرة واحدة وبعدها أوفلاين. */
object WhisperEngine {
    private const val BASE = "https://huggingface.co/csukuangfj/sherpa-onnx-whisper-medium/resolve/main/"
    private const val TOKENS = "medium-tokens.txt"
    private const val ENCODER = "medium-encoder.int8.onnx"
    private const val DECODER = "medium-decoder.int8.onnx"
    private val FILES = listOf(TOKENS, ENCODER, DECODER)

    private fun dir(ctx: Context) = File(ctx.filesDir, "whisper-medium").apply { mkdirs() }

    fun isDownloaded(ctx: Context): Boolean =
        FILES.all { File(dir(ctx), it).let { f -> f.exists() && f.length() > 0 } }

    /** بينزّل الملفات الناقصة (مع استكمال لو النت قطع). onProgress بتتنادى من خيط الشبكة. */
    fun download(ctx: Context, onProgress: (String) -> Unit) {
        val d = dir(ctx)
        FILES.forEachIndexed { idx, name ->
            val finalFile = File(d, name)
            if (finalFile.exists() && finalFile.length() > 0) return@forEachIndexed
            val part = File(d, "$name.part")
            var attempt = 0
            while (true) {
                try {
                    downloadOne(name, part, finalFile) { done, total ->
                        val pct = if (total > 0) (done * 100 / total).toInt() else 0
                        onProgress("بنزّل الموديل (مرة واحدة بس) — ملف ${idx + 1} من ${FILES.size}: $pct%  (${done / 1_000_000} من ${total / 1_000_000} ميجا)")
                    }
                    break
                } catch (e: Exception) {
                    attempt++
                    if (attempt >= 5) throw e
                    onProgress("النت ضعيف، بحاول تاني ($attempt من 5)...")
                    Thread.sleep(3000L * attempt)
                }
            }
        }
    }

    private fun downloadOne(name: String, part: File, finalFile: File, cb: (Long, Long) -> Unit) {
        val have = if (part.exists()) part.length() else 0L
        val conn = URL(BASE + name).openConnection() as HttpURLConnection
        conn.connectTimeout = 20_000
        conn.readTimeout = 30_000
        conn.instanceFollowRedirects = true
        if (have > 0) conn.setRequestProperty("Range", "bytes=$have-")
        conn.connect()
        val code = conn.responseCode
        val resumed = code == 206
        if (code != 200 && code != 206) { conn.disconnect(); throw java.io.IOException("السيرفر رجّع كود $code") }
        val len = conn.contentLengthLong
        val start = if (resumed) have else 0L
        val total = if (len > 0) start + len else -1L
        var done = start
        var lastCb = 0L
        FileOutputStream(part, resumed).use { out ->
            conn.inputStream.use { inp ->
                val buf = ByteArray(256 * 1024)
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    done += n
                    val now = System.currentTimeMillis()
                    if (now - lastCb > 400) { lastCb = now; cb(done, total) }
                }
            }
        }
        conn.disconnect()
        if (total > 0 && part.length() != total) throw java.io.IOException("الملف ناقص، هكمّل")
        cb(done, total)
        if (!part.renameTo(finalFile)) throw java.io.IOException("مقدرتش أنقل الملف")
    }

    fun load(ctx: Context): OfflineRecognizer {
        val d = dir(ctx)
        val cfg = OfflineRecognizerConfig(
            featConfig = FeatureConfig(sampleRate = 16000, featureDim = 80),
            modelConfig = OfflineModelConfig(
                whisper = OfflineWhisperModelConfig(
                    encoder = File(d, ENCODER).absolutePath,
                    decoder = File(d, DECODER).absolutePath,
                    language = "ar",
                    task = "transcribe",
                ),
                tokens = File(d, TOKENS).absolutePath,
                numThreads = 4,
                debug = false,
                provider = "cpu",
                modelType = "whisper",
            ),
            decodingMethod = "greedy_search",
        )
        return OfflineRecognizer(config = cfg)
    }

    private fun rms(a: FloatArray, from: Int, to: Int): Float {
        var s = 0.0
        for (i in from until to) s += a[i] * a[i]
        return sqrt(s / (to - from).coerceAtLeast(1)).toFloat()
    }

    /** بيقطّع الصوت قطع حوالي 20 ثانية، وبيقصّ عند أهدى لحظة (سكتة) عشان ماتتقطعش كلمة. */
    fun transcribe(rec: OfflineRecognizer, audio: FloatArray, onPartial: (String) -> Unit): String {
        val sr = 16000
        val target = 20 * sr
        val minLen = 15 * sr
        val frame = sr / 10
        val sb = StringBuilder()
        var i = 0
        while (i < audio.size) {
            var end = minOf(i + target, audio.size)
            if (audio.size - i > target) {
                var best = end
                var bestE = Float.MAX_VALUE
                var p = i + minLen
                while (p + frame <= end) {
                    val e = rms(audio, p, p + frame)
                    if (e < bestE) { bestE = e; best = p + frame / 2 }
                    p += frame
                }
                end = best
            }
            val part = audio.copyOfRange(i, end)
            if (rms(part, 0, part.size) > 0.003f) {
                val stream = rec.createStream()
                try {
                    stream.acceptWaveform(part, sr)
                    rec.decode(stream)
                    val t = rec.getResult(stream).text.trim()
                    if (t.isNotEmpty()) { if (sb.isNotEmpty()) sb.append(' '); sb.append(t) }
                } finally { stream.release() }
                onPartial(sb.toString())
            }
            i = end
        }
        return sb.toString()
    }
}

package com.moknight.speech2text

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.nio.ByteOrder

/** يفك أي ملف صوتي (mp3, m4a, wav, ogg...) ويرجّعه Float mono بتردد 16000. */
object AudioDecoder {
    fun decode(ctx: Context, uri: Uri): FloatArray {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, uri, null)
        var track = -1
        var fmt: MediaFormat? = null
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            if (f.getString(MediaFormat.KEY_MIME)!!.startsWith("audio/")) { track = i; fmt = f; break }
        }
        require(track >= 0 && fmt != null) { "الملف مفيهوش صوت" }
        ex.selectTrack(track)
        val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(fmt, null, null, 0)
        codec.start()
        var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        var buf = FloatArray(1 shl 20)
        var n = 0
        val info = MediaCodec.BufferInfo()
        var inDone = false
        var outDone = false
        while (!outDone) {
            if (!inDone) {
                val i = codec.dequeueInputBuffer(10_000)
                if (i >= 0) {
                    val b = codec.getInputBuffer(i)!!
                    val s = ex.readSampleData(b, 0)
                    if (s < 0) {
                        codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                        inDone = true
                    } else {
                        codec.queueInputBuffer(i, 0, s, ex.sampleTime, 0)
                        ex.advance()
                    }
                }
            }
            val o = codec.dequeueOutputBuffer(info, 10_000)
            if (o >= 0) {
                val ob = codec.getOutputBuffer(o)!!
                ob.position(info.offset); ob.limit(info.offset + info.size)
                val sb = ob.order(ByteOrder.nativeOrder()).asShortBuffer()
                val frames = sb.remaining() / ch
                if (n + frames > buf.size) buf = buf.copyOf(maxOf(buf.size * 2, n + frames))
                for (f in 0 until frames) {
                    var sum = 0f
                    for (c in 0 until ch) sum += sb.get()
                    buf[n++] = sum / ch / 32768f
                }
                codec.releaseOutputBuffer(o, false)
                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
            } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val nf = codec.outputFormat
                rate = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            }
        }
        codec.stop(); codec.release(); ex.release()
        return resample(buf, n, rate, 16000)
    }

    private fun resample(src: FloatArray, n: Int, from: Int, to: Int): FloatArray {
        if (from == to) return src.copyOf(n)
        val outLen = (n.toLong() * to / from).toInt()
        val out = FloatArray(outLen)
        val ratio = from.toDouble() / to
        for (i in 0 until outLen) {
            val p = i * ratio
            val a = p.toInt()
            val b = minOf(a + 1, n - 1)
            val t = (p - a).toFloat()
            out[i] = src[a] * (1 - t) + src[b] * t
        }
        return out
    }
}

package com.moknight.speech2text

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import androidx.core.graphics.PathParser
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density
fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** ألوان الثيم (ليل ماجوريل / رمل مراكشي) — فيروزي الزليج + ذهبي الزعفران + تيراكوتا. */
class Pal(
    val mid: Int, val edge: Int, val tx: Int, val sub: Int, val ac: Int,
    val gold: Int, val card: Int, val stroke: Int, val chip: Int, val dng: Int
) {
    companion object {
        private fun m(a: Int, b: Int, t: Float) = ColorUtils.blendARGB(a, b, t)
        fun lerp(a: Pal, b: Pal, t: Float) = Pal(
            m(a.mid, b.mid, t), m(a.edge, b.edge, t), m(a.tx, b.tx, t), m(a.sub, b.sub, t),
            m(a.ac, b.ac, t), m(a.gold, b.gold, t), m(a.card, b.card, t), m(a.stroke, b.stroke, t),
            m(a.chip, b.chip, t), m(a.dng, b.dng, t)
        )
    }
}

val DARK_PAL = Pal(
    0xFF1B2A6B.toInt(), 0xFF070A1F.toInt(), 0xFFF8EFDD.toInt(), 0xFFA9B0D6.toInt(),
    0xFF2EC4B6.toInt(), 0xFFF2B63C.toInt(), 0xFF141E4F.toInt(), 0x40F2B63C, 0x1AFFFFFF, 0xFFFF7A5C.toInt()
)
val LIGHT_PAL = Pal(
    0xFFFFF6E3.toInt(), 0xFFF1DDB5.toInt(), 0xFF1A1F4D.toInt(), 0xFF5B5F8A.toInt(),
    0xFF2A3FD0.toInt(), 0xFFB7791F.toInt(), 0xFFFFFBF2.toInt(), 0x55B7791F, 0x141A1F4D, 0xFFC8452F.toInt()
)

/** سمة = لون غامق + لون فاتح (الشمس/القمر بيبدّل بينهم). */
class Theme(val name: String, val dark: Pal, val light: Pal)

val THEMES = listOf(
    Theme("مراكشي", DARK_PAL, LIGHT_PAL),
    Theme(
        "زمردي",
        Pal(0xFF0F4A3F.toInt(), 0xFF03150F.toInt(), 0xFFF4F1E3.toInt(), 0xFFA8CBBE.toInt(),
            0xFF5ED6A0.toInt(), 0xFFE9C46A.toInt(), 0xFF0B3A31.toInt(), 0x40E9C46A, 0x1AFFFFFF, 0xFFFF7A5C.toInt()),
        Pal(0xFFF2FAF0.toInt(), 0xFFD6EBD8.toInt(), 0xFF0E3B2E.toInt(), 0xFF4F7A6B.toInt(),
            0xFF1E8E68.toInt(), 0xFF9A7B1F.toInt(), 0xFFFBFFF9.toInt(), 0x559A7B1F, 0x140E3B2E, 0xFFC8452F.toInt())
    ),
    Theme(
        "ياقوتي",
        Pal(0xFF5A1A2E.toInt(), 0xFF1D050C.toInt(), 0xFFFBEFE6.toInt(), 0xFFD6AFB8.toInt(),
            0xFFFF8FA3.toInt(), 0xFFF2B63C.toInt(), 0xFF3F1220.toInt(), 0x40F2B63C, 0x1AFFFFFF, 0xFFFF7A5C.toInt()),
        Pal(0xFFFFF1EC.toInt(), 0xFFF5D5CB.toInt(), 0xFF4A1424.toInt(), 0xFF8A5A66.toInt(),
            0xFFC2334F.toInt(), 0xFFB7791F.toInt(), 0xFFFFF9F6.toInt(), 0x55B7791F, 0x144A1424, 0xFFC8452F.toInt())
    ),
    Theme(
        "ملكي",
        Pal(0xFF3B1F6B.toInt(), 0xFF0F0720.toInt(), 0xFFF3EDFF.toInt(), 0xFFBDB0DE.toInt(),
            0xFFB69CFF.toInt(), 0xFFF2B63C.toInt(), 0xFF2A1650.toInt(), 0x40F2B63C, 0x1AFFFFFF, 0xFFFF7A5C.toInt()),
        Pal(0xFFFAF5FF.toInt(), 0xFFE6D8F7.toInt(), 0xFF2A1650.toInt(), 0xFF6B5A8F.toInt(),
            0xFF6B3FD0.toInt(), 0xFFB7791F.toInt(), 0xFFFFFDFF.toInt(), 0x55B7791F, 0x142A1650, 0xFFC8452F.toInt())
    ),
    Theme(
        "فحمي",
        Pal(0xFF2A2A2E.toInt(), 0xFF0A0A0B.toInt(), 0xFFF5F1E8.toInt(), 0xFFB0B0B8.toInt(),
            0xFF2EC4B6.toInt(), 0xFFF2B63C.toInt(), 0xFF1C1C20.toInt(), 0x40F2B63C, 0x1AFFFFFF, 0xFFFF7A5C.toInt()),
        Pal(0xFFFAF8F3.toInt(), 0xFFE6E2D8.toInt(), 0xFF1C1C20.toInt(), 0xFF66666E.toInt(),
            0xFF1E9E92.toInt(), 0xFFB7791F.toInt(), 0xFFFFFFFF.toInt(), 0x55B7791F, 0x141C1C20, 0xFFC8452F.toInt())
    )
)

object Icons {
    const val MIC = "M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3zm5.3-3c0 3-2.54 5.1-5.3 5.1S6.7 14 6.7 11H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c3.28-.48 6-3.3 6-6.72h-1.7z"
    const val NOTE = "M12 3v10.55c-.59-.34-1.27-.55-2-.55-2.21 0-4 1.79-4 4s1.79 4 4 4 4-1.79 4-4V7h4V3h-6z"
    const val COPY = "M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"
    const val TRASH = "M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"
    const val STOP = "M6 6h12v12H6z"
}

class IconView(ctx: Context, pathData: String) : View(ctx) {
    private var path: Path = PathParser.createPathFromPathData(pathData)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    var color: Int
        get() = paint.color
        set(v) { paint.color = v; invalidate() }

    fun setPath(pathData: String) {
        path = PathParser.createPathFromPathData(pathData)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val s = min(width, height) / 24f
        canvas.save()
        canvas.translate((width - 24f * s) / 2f, (height - 24f * s) / 2f)
        canvas.scale(s, s)
        canvas.drawPath(path, paint)
        canvas.restore()
    }
}

/** شمس <-> قمر: نفس أنيميشن الـ SVG اللي في سجل الأستاذ (الأشعة بتلف وتختفي والقمر بيتقطع). */
class SunMoonView(ctx: Context) : View(ctx) {
    /** 0 = شمس ، 1 = قمر */
    var p = 1f
        set(v) { field = v; invalidate() }
    var sunColor: Int = Color.YELLOW
        set(v) { field = v; invalidate() }

    private val moonColor = 0xFFCFE0FF.toInt()
    private val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val cutPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
    private val rayPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2.4f; strokeCap = Paint.Cap.ROUND
    }
    private val rays = PathParser.createPathFromPathData(
        "M12 2v2.4M12 19.6V22M2 12h2.4M19.6 12H22M4.9 4.9l1.7 1.7M17.4 17.4l1.7 1.7M4.9 19.1l1.7-1.7M17.4 6.6l1.7-1.7"
    )
    private var anim: ValueAnimator? = null

    private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t

    fun animateTo(target: Float) {
        anim?.cancel()
        anim = ValueAnimator.ofFloat(p, target).apply {
            duration = 800
            interpolator = OvershootInterpolator(1.2f)
            addUpdateListener { p = it.animatedValue as Float }
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        val s = min(width, height) / 24f
        val color = ColorUtils.blendARGB(sunColor, moonColor, p.coerceIn(0f, 1f))

        // القرص + القطع اللي بيعمل شكل الهلال
        val layer = c.saveLayer(0f, 0f, width.toFloat(), height.toFloat(), null)
        c.scale(s, s)
        val bs = 1f + 0.28f * p
        c.scale(bs, bs, 12f, 12f)
        bodyPaint.color = color
        c.drawCircle(12f, 12f, 5.6f, bodyPaint)
        c.drawCircle(lerp(30f, 18f, p), lerp(-10f, 7f, p), 6.3f, cutPaint)
        c.restoreToCount(layer)

        // الأشعة
        val a = (1f - p).coerceIn(0f, 1f)
        if (a > 0.01f) {
            c.save()
            c.scale(s, s)
            c.rotate(90f * p, 12f, 12f)
            val rs = lerp(1f, 0.2f, p)
            c.scale(rs, rs, 12f, 12f)
            rayPaint.color = color
            rayPaint.alpha = (255 * a).toInt()
            c.drawPath(rays, rayPaint)
            c.restore()
        }
    }
}

/** كارت صغير قابل للضغط (أيقونة + نص) بأنيميشن ضغط ونطّة خفيفة. */
class ActionButton(ctx: Context, private val iconPath: String, initialText: String) : LinearLayout(ctx) {
    private val icon = IconView(ctx, iconPath)
    private val label = TextView(ctx)
    private val bg = GradientDrawable().apply { cornerRadius = ctx.dpf(26f) }
    private var pulse: ValueAnimator? = null

    var text: CharSequence
        get() = label.text
        set(v) { label.text = v }

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER
        background = bg
        elevation = ctx.dpf(3f)
        isClickable = true
        addView(icon, LayoutParams(ctx.dp(22), ctx.dp(22)))
        label.apply {
            this.text = initialText
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            maxLines = 1
        }
        addView(label, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { marginStart = ctx.dp(10) })

        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(100).setInterpolator(null).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(280).setInterpolator(OvershootInterpolator(2.5f)).start()
            }
            false
        }
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        animate().alpha(if (enabled) 1f else 0.45f).setDuration(200).start()
    }

    fun style(p: Pal, danger: Boolean) {
        val fill = if (danger) ColorUtils.blendARGB(p.card, p.dng, 0.26f) else p.card
        bg.setColor(fill)
        bg.setStroke(context.dp(1), if (danger) p.dng else p.stroke)
        icon.color = if (danger) p.dng else p.ac
        label.setTextColor(p.tx)
    }

    /** وضع التسجيل: الأيقونة تبقى مربع إيقاف وبتنبض. */
    fun setRecording(on: Boolean) {
        icon.setPath(if (on) Icons.STOP else iconPath)
        pulse?.cancel()
        icon.scaleX = 1f
        icon.scaleY = 1f
        if (on) {
            pulse = ValueAnimator.ofFloat(1f, 1.28f).apply {
                duration = 650
                repeatCount = ValueAnimator.INFINITE
                repeatMode = ValueAnimator.REVERSE
                addUpdateListener { icon.scaleX = it.animatedValue as Float; icon.scaleY = it.animatedValue as Float }
                start()
            }
        }
    }
}


// =====================================================================
//                    عناصر الشكل المغربي الجديد
// =====================================================================

/** نجمة ثمانية (خاتم) — بتتعاد كتابتها في نفس الـ Path من غير تخصيص ذاكرة كل فريم. */
fun Path.setStar(cx: Float, cy: Float, r: Float, ratio: Float = 0.7654f) {
    rewind()
    for (i in 0 until 16) {
        val rad = if (i % 2 == 0) r else r * ratio
        val a = Math.toRadians(i * 22.5 - 90.0)
        val x = cx + (rad * cos(a)).toFloat()
        val y = cy + (rad * sin(a)).toFloat()
        if (i == 0) moveTo(x, y) else lineTo(x, y)
    }
    close()
}

/** أساس أي View بيتحرك باستمرار: بيدّي dt (ثواني بين الفريمات) و clock (الزمن الكلي). */
abstract class LoopView(ctx: Context) : View(ctx) {
    protected var dt = 0f
    protected var clock = 0f
    private var anim: ValueAnimator? = null
    private var lastNs = 0L

    private fun startLoop() {
        if (anim != null) return
        lastNs = System.nanoTime()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 1000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                val now = System.nanoTime()
                dt = ((now - lastNs) / 1e9f).coerceIn(0f, 0.1f)
                lastNs = now
                clock += dt
                invalidate()
            }
            start()
        }
    }

    private fun stopLoop() { anim?.cancel(); anim = null }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); startLoop() }
    override fun onDetachedFromWindow() { stopLoop(); super.onDetachedFromWindow() }
    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        if (visibility == VISIBLE) startLoop() else stopLoop()
    }
}

/** خلفية زليج: شبكة نجوم ومعيّنات بتنزلق ببطء (حلقة متصلة من غير قفزة). */
class ZelligeView(ctx: Context) : LoopView(ctx) {
    private val cell = ctx.dpf(80f)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dpf(1f) }
    private val star = Path().apply { setStar(0f, 0f, cell * 0.36f) }
    private val dia = Path().apply {
        val d = cell * 0.09f
        moveTo(0f, -d); lineTo(d, 0f); lineTo(0f, d); lineTo(-d, 0f); close()
    }
    private var off = 0f

    fun setTint(color: Int, alpha: Int) { paint.color = color; paint.alpha = alpha; invalidate() }

    override fun onDraw(c: Canvas) {
        off = (off + dt * cell / 45f) % cell
        var y = -cell + off
        while (y < height + cell) {
            var x = -cell + off
            while (x < width + cell) {
                c.save()
                c.translate(x, y)
                c.drawPath(star, paint)
                c.translate(cell / 2f, cell / 2f)
                c.drawPath(dia, paint)
                c.restore()
                x += cell
            }
            y += cell
        }
    }
}

/** نجمة خاتم صغيرة بتلف ببطء (للهيدر وشاشة "النص هيظهر هنا"). */
class KhatamView(ctx: Context, private val spin: Float = 18f) : LoopView(ctx) {
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ctx.dpf(1.4f); strokeJoin = Paint.Join.ROUND
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val outer = Path()
    private val inner = Path()
    private var rot = 0f

    var color: Int = Color.WHITE
        set(v) { field = v; stroke.color = v; fill.color = v; fill.alpha = 70; invalidate() }

    override fun onDraw(c: Canvas) {
        rot += dt * spin
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - stroke.strokeWidth
        outer.setStar(cx, cy, r)
        inner.setStar(cx, cy, r * 0.55f)
        c.save(); c.rotate(rot, cx, cy); c.drawPath(outer, stroke); c.restore()
        c.save(); c.rotate(-rot * 1.5f, cx, cy); c.drawPath(inner, fill); c.restore()
    }
}

/** نجمتين صغيرين بيلفوا عكس بعض (نفس شكل نجوم كرة المايك). */
class DualStarView(ctx: Context, private val spin: Float = 26f) : LoopView(ctx) {
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ctx.dpf(1.5f); strokeJoin = Paint.Join.ROUND
    }
    private val sp = Path()
    private var rot = 0f

    var color: Int = Color.WHITE
        set(v) { field = v; stroke.color = v; invalidate() }

    override fun onDraw(c: Canvas) {
        rot += dt * spin
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - stroke.strokeWidth
        c.save(); c.rotate(rot, cx, cy)
        sp.setStar(cx, cy, r); stroke.alpha = 220; c.drawPath(sp, stroke)
        c.restore()
        c.save(); c.rotate(-rot * 1.4f, cx, cy)
        sp.setStar(cx, cy, r * 0.86f); stroke.alpha = 120; c.drawPath(sp, stroke)
        c.restore()
    }
}

/** شريط تحميل رفيع: قطعة ذهبية بتنزلق. بيظهر ويختفي بنعومة. */
class LoadingBar(ctx: Context) : LoopView(ctx) {
    private val track = Paint(Paint.ANTI_ALIAS_FLAG)
    private val seg = Paint(Paint.ANTI_ALIAS_FLAG)

    var color: Int = Color.WHITE
        set(v) { field = v; track.color = v; track.alpha = 40; seg.color = v; invalidate() }

    var busy: Boolean = false
        set(v) { field = v; animate().alpha(if (v) 1f else 0f).setDuration(250).start() }

    init { alpha = 0f }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val rr = h / 2f
        c.drawRoundRect(0f, 0f, w, h, rr, rr, track)
        val segW = w * 0.38f
        val ph = (clock / 1.3f) % 1f
        val x0 = -segW + ph * (w + segW)
        c.save()
        c.clipRect(0f, 0f, w, h)
        c.drawRoundRect(x0, 0f, x0 + segW, h, rr, rr, seg)
        c.restore()
    }
}

/**
 * زرار التسجيل الكبير: كرة متدرجة + نجمتين بيلفوا عكس بعض + موجات صوت بتتوسّع وقت التسجيل.
 * الـ level (0..1) من الميكروفون بيخلّي الكرة والنجوم "تتنفس" مع صوتك.
 */
class RecordOrb(ctx: Context) : LoopView(ctx) {
    @Volatile var level = 0f

    var recording = false
        set(v) { field = v; rebuild() }

    private var pal: Pal? = null
    private val mic = PathParser.createPathFromPathData(Icons.MIC)
    private val stopP = PathParser.createPathFromPathData(Icons.STOP)
    private val orbPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = ctx.dpf(2f) }
    private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = ctx.dpf(1.5f); strokeJoin = Paint.Join.ROUND
    }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val sp = Path()
    private var rot = 0f
    private var smooth = 0f

    init {
        isClickable = true
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(100).setInterpolator(null).start()
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    v.animate().scaleX(1f).scaleY(1f).setDuration(320).setInterpolator(OvershootInterpolator(3f)).start()
            }
            false
        }
    }

    override fun setEnabled(enabled: Boolean) {
        super.setEnabled(enabled)
        animate().alpha(if (enabled) 1f else 0.5f).setDuration(200).start()
    }

    fun style(p: Pal) { pal = p; rebuild() }

    private fun rebuild() {
        val p = pal ?: return
        if (width == 0 || height == 0) return
        val cx = width / 2f
        val cy = height / 2f
        val big = min(width, height) / 2f
        val orbR = big * 0.56f
        val a = if (recording) p.dng else p.ac
        val b = ColorUtils.blendARGB(a, p.gold, 0.45f)
        orbPaint.shader = LinearGradient(cx - orbR, cy - orbR, cx + orbR, cy + orbR, a, b, Shader.TileMode.CLAMP)
        glowPaint.shader = RadialGradient(
            cx, cy, big, ColorUtils.setAlphaComponent(a, 90), ColorUtils.setAlphaComponent(a, 0), Shader.TileMode.CLAMP
        )
        starPaint.color = p.gold
        iconPaint.color = p.mid
        ringPaint.color = a
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { super.onSizeChanged(w, h, ow, oh); rebuild() }

    override fun onDraw(c: Canvas) {
        if (pal == null) return
        val cx = width / 2f
        val cy = height / 2f
        val big = min(width, height) / 2f
        val orbR = big * 0.56f

        smooth += (level - smooth) * 0.2f
        rot += dt * (if (recording) 46f else 14f)
        val breathe = 1f + 0.015f * sin(clock * 2f) + 0.07f * smooth

        c.drawCircle(cx, cy, big, glowPaint)

        if (recording) {
            for (k in 0 until 3) {
                val ph = ((clock / 1.8f) + k / 3f) % 1f
                ringPaint.alpha = ((1f - ph) * 150).toInt()
                c.drawCircle(cx, cy, orbR * breathe + (big - orbR) * ph, ringPaint)
            }
        }

        val sr = big * 0.93f
        c.save(); c.rotate(rot, cx, cy)
        sp.setStar(cx, cy, sr); starPaint.alpha = 210; c.drawPath(sp, starPaint)
        c.restore()
        c.save(); c.rotate(-rot * 1.4f, cx, cy)
        sp.setStar(cx, cy, sr * 0.86f); starPaint.alpha = 110; c.drawPath(sp, starPaint)
        c.restore()

        val r = orbR * breathe
        c.drawCircle(cx, cy, r, orbPaint)

        val s = r * 1.1f / 24f
        c.save()
        c.translate(cx - 12f * s, cy - 12f * s)
        c.scale(s, s)
        c.drawPath(if (recording) stopP else mic, iconPaint)
        c.restore()
    }
}

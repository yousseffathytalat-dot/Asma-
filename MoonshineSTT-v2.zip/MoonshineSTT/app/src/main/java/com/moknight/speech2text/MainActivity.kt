package com.moknight.speech2text

import ai.moonshine.voice.JNI
import ai.moonshine.voice.Transcriber
import android.Manifest
import android.animation.ValueAnimator
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.io.ByteArrayOutputStream
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {
    // اسم فولدر الموديل جوه app/src/main/assets (اقرا README)
    private val modelDir = "base-ar"
    private val transcriber = Transcriber()
    @Volatile private var ready = false
    @Volatile private var recording = false
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var hint: TextView
    private lateinit var orb: RecordOrb
    private lateinit var zellige: ZelligeView
    private lateinit var headStar: KhatamView
    private lateinit var hintStar: KhatamView
    private lateinit var hintBox: LinearLayout
    private lateinit var subTv: TextView
    private lateinit var loadBar: LoadingBar
    private val ui = Handler(Looper.getMainLooper())
    private var recStart = 0L
    private val timerTick = object : Runnable {
        override fun run() {
            if (!recording) return
            val sec = (SystemClock.elapsedRealtime() - recStart) / 1000
            status.text = "بسجّل...  %02d:%02d".format(sec / 60, sec % 60)
            ui.postDelayed(this, 250)
        }
    }
    private lateinit var fileBtn: ActionButton
    private lateinit var copyBtn: ActionButton
    private lateinit var clearBtn: ActionButton

    // ---- الثيم ----
    private lateinit var prefs: SharedPreferences
    private lateinit var bg: GradientDrawable
    private lateinit var topBg: GradientDrawable
    private lateinit var toggleBg: GradientDrawable
    private lateinit var resBg: GradientDrawable
    private lateinit var titleTv: TextView
    private lateinit var sunMoon: SunMoonView
    private lateinit var barsCtrl: WindowInsetsControllerCompat
    private var dark = true
    private var themeT = 0f          // 0 = غامق ، 1 = فاتح
    private var themeAnim: ValueAnimator? = null
    private var lightBars: Boolean? = null

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) work("بفك الملف الصوتي...") { AudioDecoder.decode(this, uri) }
    }
    private val askMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRecording() else toast("لازم تسمح بالميكروفون")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        prefs = getSharedPreferences("ui", Context.MODE_PRIVATE)
        dark = prefs.getBoolean("dark", true)

        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        // الخلفية (نفس تدرج سجل الأستاذ)
        bg = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = resources.displayMetrics.heightPixels * 0.9f
            setGradientCenter(0.5f, 0f)
            colors = intArrayOf(DARK_PAL.mid, DARK_PAL.edge)
        }
        val frame = FrameLayout(this).apply {
            background = bg
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        zellige = ZelligeView(this)
        frame.addView(zellige, FrameLayout.LayoutParams(match, match))
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(40), dp(14), dp(14))
        }
        frame.addView(col, FrameLayout.LayoutParams(match, match))

        // الشريط العلوي: العنوان + (شمس/قمر) مكان زرار الإعدادات
        topBg = GradientDrawable().apply { cornerRadius = dpf(30f) }
        val top = FrameLayout(this).apply { background = topBg; elevation = dpf(3f) }
        titleTv = TextView(this).apply {
            text = "كلام لنص"
            textSize = 19f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        subTv = TextView(this).apply {
            text = "من الصوت إلى الكلمات · بدون إنترنت"
            textSize = 10.5f
            gravity = Gravity.CENTER
        }
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(titleTv, LinearLayout.LayoutParams(wrap, wrap))
            addView(subTv, LinearLayout.LayoutParams(wrap, wrap))
        }
        top.addView(titleBox, FrameLayout.LayoutParams(wrap, wrap, Gravity.CENTER))
        headStar = KhatamView(this, 20f)
        top.addView(headStar, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.START or Gravity.CENTER_VERTICAL).apply { marginStart = dp(16) })
        toggleBg = GradientDrawable().apply { shape = GradientDrawable.OVAL }
        sunMoon = SunMoonView(this).apply { p = if (dark) 1f else 0f }
        val toggle = FrameLayout(this).apply {
            background = toggleBg
            isClickable = true
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(90).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3f)).start()
                }
                false
            }
            setOnClickListener { toggleTheme(it) }
        }
        toggle.addView(sunMoon, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        top.addView(toggle, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(6) })
        col.addView(top, LinearLayout.LayoutParams(match, dp(62)))

        // الحالة + شريط التحميل
        status = TextView(this).apply { textSize = 13f; text = "بحمّل الموديل..."; gravity = Gravity.CENTER }
        col.addView(status, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(10) })
        loadBar = LoadingBar(this).apply { busy = true }
        col.addView(loadBar, LinearLayout.LayoutParams(dp(130), dp(3)).apply { topMargin = dp(6); gravity = Gravity.CENTER_HORIZONTAL })

        // زرار التسجيل الكبير (الكرة + النجوم)
        orb = RecordOrb(this).apply {
            isEnabled = false
            setOnClickListener { tick(it); toggleRecord() }
        }
        col.addView(orb, LinearLayout.LayoutParams(dp(150), dp(150)).apply { topMargin = dp(2); gravity = Gravity.CENTER_HORIZONTAL })

        // اختيار ملف صوتي
        fileBtn = ActionButton(this, Icons.NOTE, "اختار ملف صوتي").apply {
            isEnabled = false
            setOnClickListener { tick(it); pickFile.launch(arrayOf("audio/*")) }
        }
        col.addView(fileBtn, LinearLayout.LayoutParams(match, dp(50)).apply { topMargin = dp(2) })

        // مساحة النص (كبيرة)
        resBg = GradientDrawable().apply { cornerRadius = dpf(24f) }
        val resCard = FrameLayout(this).apply { background = resBg; elevation = dpf(3f); clipToOutline = true }
        result = TextView(this).apply {
            textSize = 19f
            setTextIsSelectable(true)
            setLineSpacing(0f, 1.25f)
            setPadding(dp(18), dp(16), dp(18), dp(16))
            gravity = Gravity.START
        }
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(result) }
        hint = TextView(this).apply {
            text = "اضغط الكرة وتكلّم\nأو اختار ملف صوتي"
            textSize = 15f
            gravity = Gravity.CENTER
            setLineSpacing(0f, 1.2f)
        }
        hintStar = KhatamView(this, 12f).apply { alpha = 0.7f }
        hintBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(hintStar, LinearLayout.LayoutParams(dp(54), dp(54)).apply { bottomMargin = dp(10) })
            addView(hint, LinearLayout.LayoutParams(wrap, wrap))
        }
        resCard.addView(scroll, FrameLayout.LayoutParams(match, match))
        resCard.addView(hintBox, FrameLayout.LayoutParams(match, match))
        result.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val empty = s.isNullOrEmpty()
                if (!empty && hintBox.visibility == View.VISIBLE) {
                    hintBox.animate().alpha(0f).setDuration(180).withEndAction { if (!result.text.isNullOrEmpty()) hintBox.visibility = View.GONE }.start()
                } else if (empty) {
                    hintBox.visibility = View.VISIBLE
                    hintBox.animate().alpha(1f).setDuration(220).start()
                }
            }
        })
        col.addView(resCard, LinearLayout.LayoutParams(match, 0, 1f).apply { topMargin = dp(12) })

        // تحت: انسخ النص + امسح
        copyBtn = ActionButton(this, Icons.COPY, "انسخ النص").apply {
            setOnClickListener {
                tick(it)
                if (result.text.isNullOrBlank()) toast("مفيش نص")
                else {
                    (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("text", result.text))
                    copyBtn.text = "اتنسخ ✓"
                    ui.postDelayed({ copyBtn.text = "انسخ النص" }, 1400)
                }
            }
        }
        clearBtn = ActionButton(this, Icons.TRASH, "امسح").apply {
            setOnClickListener { tick(it); result.text = "" }
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(copyBtn, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(5) })
        row.addView(clearBtn, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginStart = dp(5) })
        col.addView(row, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(12) })

        setContentView(frame)
        barsCtrl = WindowInsetsControllerCompat(window, frame)
        ViewCompat.setOnApplyWindowInsetsListener(frame) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            col.setPadding(dp(14), b.top + dp(8), dp(14), b.bottom + dp(10))
            insets
        }
        applyTheme(if (dark) 0f else 1f)

        // دخول العناصر واحد ورا التاني
        listOf<View>(top, status, fileBtn, resCard, row).forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = dpf(24f)
            v.animate().alpha(1f).translationY(0f).setStartDelay(70L * i).setDuration(400)
                .setInterpolator(DecelerateInterpolator(2f)).start()
        }
        orb.alpha = 0f; orb.scaleX = 0.5f; orb.scaleY = 0.5f
        orb.animate().alpha(if (orb.isEnabled) 1f else 0.5f).scaleX(1f).scaleY(1f).setStartDelay(160).setDuration(750)
            .setInterpolator(OvershootInterpolator(1.7f)).start()
        zellige.alpha = 0f
        zellige.animate().alpha(1f).setDuration(1200).start()

        Thread {
            try {
                transcriber.loadFromAssets(this, modelDir, JNI.MOONSHINE_MODEL_ARCH_BASE)
                ready = true
                runOnUiThread { status.text = "جاهز — اضغط الكرة وتكلّم"; loadBar.busy = false; fileBtn.isEnabled = true; orb.isEnabled = true }
            } catch (e: Throwable) {
                runOnUiThread { status.text = "الموديل مش لاقيه: ${e.message}"; loadBar.busy = false }
            }
        }.start()
    }

    // ================= الثيم =================

    private fun toggleTheme(v: View) {
        tick(v)
        dark = !dark
        prefs.edit().putBoolean("dark", dark).apply()
        sunMoon.animateTo(if (dark) 1f else 0f)
        themeAnim?.cancel()
        themeAnim = ValueAnimator.ofFloat(themeT, if (dark) 0f else 1f).apply {
            duration = 450
            addUpdateListener { applyTheme(it.animatedValue as Float) }
            start()
        }
    }

    private fun applyTheme(t: Float) {
        themeT = t
        val p = Pal.lerp(DARK_PAL, LIGHT_PAL, t.coerceIn(0f, 1f))
        bg.colors = intArrayOf(p.mid, p.edge)
        topBg.setColor(p.card); topBg.setStroke(dp(1), p.stroke)
        resBg.setColor(p.card); resBg.setStroke(dp(1), p.stroke)
        toggleBg.setColor(p.chip)
        titleTv.setTextColor(p.gold)
        subTv.setTextColor(p.sub)
        sunMoon.sunColor = p.gold
        zellige.setTint(p.gold, (26 + 16 * t).toInt())
        headStar.color = p.gold
        hintStar.color = p.gold
        loadBar.color = p.gold
        status.setTextColor(if (recording) p.dng else p.sub)
        result.setTextColor(p.tx)
        hint.setTextColor(p.sub)
        fileBtn.style(p, false)
        orb.style(p)
        copyBtn.style(p, false)
        clearBtn.style(p, false)
        val light = t > 0.5f
        if (lightBars != light) {
            lightBars = light
            barsCtrl.isAppearanceLightStatusBars = light
            barsCtrl.isAppearanceLightNavigationBars = light
        }
    }

    private fun tick(v: View) { v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) }

    // ================= التسجيل والتحويل (زي ما هو) =================

    private fun toggleRecord() {
        if (recording) { recording = false; return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRecording()
        else askMic.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startRecording() {
        recording = true
        orb.recording = true
        fileBtn.isEnabled = false
        recStart = SystemClock.elapsedRealtime()
        status.text = "بسجّل...  00:00"
        ui.post(timerTick)
        applyTheme(themeT)
        Thread {
            val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = AudioRecord(MediaRecorder.AudioSource.MIC, 16000, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, minBuf * 2)
            val bytes = ByteArrayOutputStream()
            val tmp = ByteArray(minBuf)
            rec.startRecording()
            while (recording) {
                val r = rec.read(tmp, 0, tmp.size)
                if (r > 0) {
                    bytes.write(tmp, 0, r)
                    // مستوى الصوت للأنيميشن
                    var sum = 0.0
                    var n = 0
                    var k = 0
                    while (k + 1 < r) {
                        val v = ((tmp[k].toInt() and 0xff) or (tmp[k + 1].toInt() shl 8)).toShort() / 32768.0
                        sum += v * v; n++; k += 2
                    }
                    if (n > 0) orb.level = (sqrt(sum / n) * 7.0).toFloat().coerceIn(0f, 1f)
                }
            }
            rec.stop(); rec.release()
            orb.level = 0f
            val b = bytes.toByteArray()
            val samples = FloatArray(b.size / 2) { i ->
                ((b[2 * i].toInt() and 0xff) or (b[2 * i + 1].toInt() shl 8)).toShort() / 32768f
            }
            runOnUiThread {
                orb.recording = false
                applyTheme(themeT)
            }
            transcribe(samples)
        }.start()
    }

    private fun work(msg: String, load: () -> FloatArray) {
        status.text = msg; loadBar.busy = true; fileBtn.isEnabled = false; orb.isEnabled = false
        Thread {
            try { transcribe(load()) }
            catch (e: Throwable) { runOnUiThread { status.text = "حصل خطأ: ${e.message}"; loadBar.busy = false; fileBtn.isEnabled = true; orb.isEnabled = true } }
        }.start()
    }

    /** بيقطّع الصوت لقطع 20 ثانية ويجمّع النص. */
    private fun transcribe(audio: FloatArray) {
        runOnUiThread { status.text = "بحوّل لنص..."; loadBar.busy = true; orb.isEnabled = false }
        try {
            val chunk = 20 * 16000
            val sb = StringBuilder()
            var i = 0
            while (i < audio.size) {
                val part = audio.copyOfRange(i, minOf(i + chunk, audio.size))
                val t = transcriber.transcribeWithoutStreaming(part, 16000)
                for (line in t.lines) sb.append(line.text).append(' ')
                val partial = sb.toString()
                runOnUiThread { result.text = partial }
                i += chunk
            }
            runOnUiThread { status.text = "خلص ✓" }
        } catch (e: Throwable) {
            runOnUiThread { status.text = "حصل خطأ: ${e.message}" }
        }
        runOnUiThread { loadBar.busy = false; fileBtn.isEnabled = true; orb.isEnabled = true }
    }

    override fun onDestroy() {
        recording = false
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}

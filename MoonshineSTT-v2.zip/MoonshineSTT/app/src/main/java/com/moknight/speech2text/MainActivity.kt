package com.moknight.speech2text

import ai.moonshine.voice.JNI
import ai.moonshine.voice.Transcriber
import android.Manifest
import android.animation.ValueAnimator
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import java.io.ByteArrayOutputStream
import kotlin.math.sqrt

class MainActivity : AppCompatActivity() {
    // اسم فولدر الموديل جوه app/src/main/assets (اقرا README)
    private val modelDir = "base-ar"
    private var transcriber = Transcriber()
    // نوع الموديل اللي لقيناه في الـ assets: false = encoder_model.ort (عادي) ، true = streaming (encoder.ort + adapter + cross_kv ...)
    private var streamingModel = false
    @Volatile private var ready = false
    @Volatile private var recording = false
    private lateinit var status: TextView
    private lateinit var result: TextView
    private lateinit var hint: TextView
    private lateinit var orb: RecordOrb
    private lateinit var zellige: ZelligeView
    private lateinit var headStar: DualStarView
    private lateinit var hintStar: KhatamView
    private lateinit var hintBox: LinearLayout
    private lateinit var subTv: TextView
    private lateinit var loadBar: LoadingBar
    private val ui = Handler(Looper.getMainLooper())
    private var recStart = 0L
    private val timerTick = object : Runnable {
        override fun run() {
            if (!recording) return
            val sec = (SystemClock.elapsedRealtime() - recStart) / 1000
            status.text = "بسجّل...  %02d:%02d".format(sec / 60, sec % 60)
            ui.postDelayed(this, 250)
        }
    }
    private lateinit var fileBtn: ActionButton
    private lateinit var copyBtn: ActionButton
    private lateinit var clearBtn: ActionButton

    // ---- الثيم ----
    private lateinit var prefs: SharedPreferences
    private lateinit var bg: GradientDrawable
    private lateinit var topBg: GradientDrawable
    private lateinit var toggleBg: GradientDrawable
    private lateinit var resBg: GradientDrawable
    private lateinit var titleTv: TextView
    private lateinit var sunMoon: SunMoonView
    private lateinit var barsCtrl: WindowInsetsControllerCompat
    private var dark = true
    private var themeIdx = 0
    private var themeSwitch: ValueAnimator? = null
    private var themeT = 0f          // 0 = غامق ، 1 = فاتح
    private var themeAnim: ValueAnimator? = null
    private var lightBars: Boolean? = null

    private val pickFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) work("بفك الملف الصوتي...") { AudioDecoder.decode(this, uri) }
    }
    private val askMic = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startRecording() else toast("لازم تسمح بالميكروفون")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        prefs = getSharedPreferences("ui", Context.MODE_PRIVATE)
        dark = prefs.getBoolean("dark", true)
        themeIdx = prefs.getInt("theme", 0).coerceIn(0, THEMES.size - 1)

        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        // الخلفية (نفس تدرج سجل الأستاذ)
        bg = GradientDrawable().apply {
            gradientType = GradientDrawable.RADIAL_GRADIENT
            gradientRadius = resources.displayMetrics.heightPixels * 0.9f
            setGradientCenter(0.5f, 0f)
            colors = intArrayOf(DARK_PAL.mid, DARK_PAL.edge)
        }
        val frame = FrameLayout(this).apply {
            background = bg
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        zellige = ZelligeView(this)
        frame.addView(zellige, FrameLayout.LayoutParams(match, match))
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(40), dp(14), dp(14))
        }
        frame.addView(col, FrameLayout.LayoutParams(match, match))

        // الشريط العلوي: العنوان + (شمس/قمر) مكان زرار الإعدادات
        topBg = GradientDrawable().apply { cornerRadius = dpf(30f) }
        val top = FrameLayout(this).apply { background = topBg; elevation = dpf(3f) }
        titleTv = TextView(this).apply {
            text = "كلام لنص"
            textSize = 19f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        subTv = TextView(this).apply {
            text = "من الصوت إلى الكلمات · بدون إنترنت"
            textSize = 10.5f
            gravity = Gravity.CENTER
        }
        val titleBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(titleTv, LinearLayout.LayoutParams(wrap, wrap))
            addView(subTv, LinearLayout.LayoutParams(wrap, wrap))
        }
        top.addView(titleBox, FrameLayout.LayoutParams(wrap, wrap, Gravity.CENTER))
        headStar = DualStarView(this).apply {
            isClickable = true
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(90).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3f)).start()
                }
                false
            }
            setOnClickListener { showCredit(it) }
        }
        top.addView(headStar, FrameLayout.LayoutParams(dp(32), dp(32), Gravity.START or Gravity.CENTER_VERTICAL).apply { marginStart = dp(13) })
        toggleBg = GradientDrawable().apply { shape = GradientDrawable.OVAL }
        sunMoon = SunMoonView(this).apply { p = if (dark) 1f else 0f }
        val toggle = FrameLayout(this).apply {
            background = toggleBg
            isClickable = true
            setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.88f).scaleY(0.88f).setDuration(90).start()
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                        v.animate().scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(OvershootInterpolator(3f)).start()
                }
                false
            }
            setOnClickListener { toggleTheme(it) }
        }
        toggle.addView(sunMoon, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        top.addView(toggle, FrameLayout.LayoutParams(dp(42), dp(42), Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(6) })
        col.addView(top, LinearLayout.LayoutParams(match, dp(62)))

        // الحالة + شريط التحميل
        status = TextView(this).apply { textSize = 13f; text = "بحمّل الموديل..."; gravity = Gravity.CENTER }
        col.addView(status, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(10) })
        loadBar = LoadingBar(this).apply { busy = true }
        col.addView(loadBar, LinearLayout.LayoutParams(dp(130), dp(3)).apply { topMargin = dp(6); gravity = Gravity.CENTER_HORIZONTAL })

        // زرار التسجيل الكبير (الكرة + النجوم)
        orb = RecordOrb(this).apply {
            isEnabled = false
            setOnClickListener { tick(it); toggleRecord() }
        }
        col.addView(orb, LinearLayout.LayoutParams(dp(150), dp(150)).apply { topMargin = dp(2); gravity = Gravity.CENTER_HORIZONTAL })

        // اختيار ملف صوتي
        fileBtn = ActionButton(this, Icons.NOTE, "اختار ملف صوتي").apply {
            isEnabled = false
            setOnClickListener { tick(it); pickFile.launch(arrayOf("audio/*")) }
        }
        col.addView(fileBtn, LinearLayout.LayoutParams(match, dp(50)).apply { topMargin = dp(2) })

        // مساحة النص (كبيرة)
        resBg = GradientDrawable().apply { cornerRadius = dpf(24f) }
        val resCard = FrameLayout(this).apply { background = resBg; elevation = dpf(3f); clipToOutline = true }
        result = TextView(this).apply {
            textSize = 19f
            setTextIsSelectable(true)
            setLineSpacing(0f, 1.25f)
            setPadding(dp(18), dp(16), dp(18), dp(16))
            gravity = Gravity.START
        }
        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(result) }
        hint = TextView(this).apply {
            text = "اضغط الكرة وتكلّم\nأو اختار ملف صوتي"
            textSize = 15f
            gravity = Gravity.CENTER
            setLineSpacing(0f, 1.2f)
        }
        hintStar = KhatamView(this, 12f).apply { alpha = 0.7f }
        hintBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(hintStar, LinearLayout.LayoutParams(dp(54), dp(54)).apply { bottomMargin = dp(10) })
            addView(hint, LinearLayout.LayoutParams(wrap, wrap))
        }
        resCard.addView(scroll, FrameLayout.LayoutParams(match, match))
        resCard.addView(hintBox, FrameLayout.LayoutParams(match, match))
        result.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val empty = s.isNullOrEmpty()
                if (!empty && hintBox.visibility == View.VISIBLE) {
                    hintBox.animate().alpha(0f).setDuration(180).withEndAction { if (!result.text.isNullOrEmpty()) hintBox.visibility = View.GONE }.start()
                } else if (empty) {
                    hintBox.visibility = View.VISIBLE
                    hintBox.animate().alpha(1f).setDuration(220).start()
                }
            }
        })
        col.addView(resCard, LinearLayout.LayoutParams(match, 0, 1f).apply { topMargin = dp(12) })

        // تحت: انسخ النص + امسح
        copyBtn = ActionButton(this, Icons.COPY, "انسخ النص").apply {
            setOnClickListener {
                tick(it)
                if (result.text.isNullOrBlank()) toast("مفيش نص")
                else {
                    (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                        .setPrimaryClip(ClipData.newPlainText("text", result.text))
                    copyBtn.text = "اتنسخ ✓"
                    ui.postDelayed({ copyBtn.text = "انسخ النص" }, 1400)
                }
            }
        }
        clearBtn = ActionButton(this, Icons.TRASH, "امسح").apply {
            setOnClickListener { tick(it); result.text = "" }
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(copyBtn, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginEnd = dp(5) })
        row.addView(clearBtn, LinearLayout.LayoutParams(0, dp(50), 1f).apply { marginStart = dp(5) })
        col.addView(row, LinearLayout.LayoutParams(match, wrap).apply { topMargin = dp(12) })

        setContentView(frame)
        barsCtrl = WindowInsetsControllerCompat(window, frame)
        ViewCompat.setOnApplyWindowInsetsListener(frame) { _, insets ->
            val b = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout())
            col.setPadding(dp(14), b.top + dp(8), dp(14), b.bottom + dp(10))
            insets
        }
        applyTheme(if (dark) 0f else 1f)

        // دخول العناصر واحد ورا التاني
        listOf<View>(top, status, fileBtn, resCard, row).forEachIndexed { i, v ->
            v.alpha = 0f
            v.translationY = dpf(24f)
            v.animate().alpha(1f).translationY(0f).setStartDelay(70L * i).setDuration(400)
                .setInterpolator(DecelerateInterpolator(2f)).start()
        }
        orb.alpha = 0f; orb.scaleX = 0.5f; orb.scaleY = 0.5f
        orb.animate().alpha(if (orb.isEnabled) 1f else 0.5f).scaleX(1f).scaleY(1f).setStartDelay(160).setDuration(750)
            .setInterpolator(OvershootInterpolator(1.7f)).start()
        zellige.alpha = 0f
        zellige.animate().alpha(1f).setDuration(1200).start()

        Thread {
            try {
                loadMoonshine()
                ready = true
                runOnUiThread { status.text = "جاهز — اضغط الكرة وتكلّم"; loadBar.busy = false; fileBtn.isEnabled = true; orb.isEnabled = true }
            } catch (e: Throwable) {
                val msg = e.message ?: e.toString()
                val sysOk = try { SpeechRecognizer.isRecognitionAvailable(this) } catch (t: Throwable) { false }
                runOnUiThread {
                    loadBar.busy = false
                    status.textSize = 11f
                    if (sysOk) {
                        fallbackSys = true
                        orb.isEnabled = true
                        status.text = "[نسخة 1.2] موديل Moonshine ماشتغلش، فشغّلت التعرف المدمج في الموبايل للتسجيل (اختيار ملف صوتي محتاج Moonshine).\n$msg"
                    } else {
                        status.text = "[نسخة 1.2] موديل Moonshine ماشتغلش:\n$msg"
                    }
                }
            }
        }.start()
    }



    // ================= تحميل Moonshine (بالـ reflection عشان نشتغل مع أي إصدار من المكتبة) =================

    private fun copyAssetDir(src: String, dst: java.io.File) {
        val names = assets.list(src) ?: emptyArray()
        if (names.isEmpty()) {
            if (dst.exists() && dst.length() > 0) return
            dst.parentFile?.mkdirs()
            assets.open(src).use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
        } else {
            dst.mkdirs()
            for (n in names) copyAssetDir("$src/$n", java.io.File(dst, n))
        }
    }

    private fun loadMoonshine() {
        val dir = findModelDir()
        val files = java.io.File(filesDir, "model/$dir")
        copyAssetDir(dir, files)

        val consts = JNI::class.java.fields
            .filter { it.name.startsWith("MOONSHINE_MODEL_ARCH") && it.type == Int::class.javaPrimitiveType }
            .map { it.name.removePrefix("MOONSHINE_MODEL_ARCH_") to it.getInt(null) }
        fun rank(n: String): Int {
            val st = n.contains("STREAMING")
            val base = when {
                n.startsWith("BASE") -> 0
                n.startsWith("SMALL") -> 1
                n.startsWith("TINY") -> 2
                else -> 3
            }
            return (if (st == streamingModel) 0 else 10) + base
        }
        val order = ArrayList<Pair<String, Int>>(consts.sortedBy { rank(it.first) })
        if (streamingModel && consts.none { it.first.contains("STREAMING") }) {
            order.addAll(listOf("g3" to 3, "g4" to 4, "g2" to 2, "g5" to 5))
        }

        val tc = Transcriber::class.java
        val errors = ArrayList<String>()
        for ((nm, v) in order) {
            val t = Transcriber()
            for (mode in 0..1) {
                try {
                    if (mode == 0) {
                        val mth = tc.methods.firstOrNull { it.name == "loadFromFiles" && it.parameterTypes.size == 2 } ?: continue
                        mth.invoke(t, files.absolutePath, v)
                    } else {
                        val mth = tc.methods.firstOrNull { it.name == "loadFromAssets" && it.parameterTypes.size == 3 } ?: continue
                        mth.invoke(t, this, dir, v)
                    }
                    transcriber = t
                    return
                } catch (e: Throwable) {
                    val c = (e as? java.lang.reflect.InvocationTargetException)?.targetException ?: e
                    errors.add("$nm/${if (mode == 0) "files" else "assets"}: ${c.message}")
                }
            }
        }
        val loads = tc.methods.filter { it.name.startsWith("load") }.map { it.name + "/" + it.parameterTypes.size }.distinct()
        throw IllegalStateException(
            "الأنواع: " + consts.joinToString(" ") { it.first + "=" + it.second } +
                "\nدوال التحميل: " + loads.joinToString(" ") +
                "\n" + errors.distinct().take(4).joinToString("\n")
        )
    }

    // ================= تعرف النظام (احتياطي لو Moonshine ماشتغلش) =================

    private var fallbackSys = false
    private var sr: SpeechRecognizer? = null
    private val sysAcc = StringBuilder()
    private var sysIntent: Intent? = null

    private fun startSystemRecognition() {
        recording = true
        orb.recording = true
        fileBtn.isEnabled = false
        recStart = SystemClock.elapsedRealtime()
        status.textSize = 13f
        status.text = "بسمع...  00:00"
        ui.post(timerTick)
        applyTheme(themeT)
        sysAcc.setLength(0)
        val existing = result.text?.toString().orEmpty()
        if (existing.isNotBlank()) sysAcc.append(existing.trim()).append(' ')
        val r = SpeechRecognizer.createSpeechRecognizer(this)
        sr = r
        sysIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
        }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { orb.level = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f) }
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(t: Int, p: Bundle?) {}
            override fun onPartialResults(p: Bundle?) {
                val t = p?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: return
                result.text = sysAcc.toString() + t
            }
            override fun onResults(res: Bundle?) {
                val t = res?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!t.isNullOrBlank()) sysAcc.append(t).append(' ')
                result.text = sysAcc.toString()
                if (recording) restartSys() else finishSys("خلص ✓")
            }
            override fun onError(error: Int) {
                // 7 = مفيش كلام متعرّف عليه ، 6 = سكوت: نكمّل سماع طول ما الزرار شغال
                if (recording && (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT)) restartSys()
                else finishSys("التعرف المدمج وقف (كود $error) — ممكن يحتاج إنترنت أو حزمة عربي أوفلاين من إعدادات الموبايل")
            }
        })
        r.startListening(sysIntent)
    }

    private fun restartSys() {
        val r = sr ?: return
        ui.postDelayed({ if (recording && sr === r) { try { r.startListening(sysIntent) } catch (e: Throwable) { finishSys("حصل خطأ: ${e.message}") } } }, 200)
    }

    private fun finishSys(msg: String) {
        recording = false
        orb.recording = false
        orb.level = 0f
        try { sr?.destroy() } catch (e: Throwable) {}
        sr = null
        status.text = msg
        applyTheme(themeT)
    }

    // ================= الموديل =================

    /** بيدوّر على فولدر فيه encoder_model.ort (حتى لو الفولدر اتسمّى أو اتنسخ بشكل مختلف). */
    private fun findModelDir(): String {
        val am = assets
        fun kids(p: String): Array<String> = try { am.list(p) ?: emptyArray() } catch (e: Exception) { emptyArray() }
        fun search(p: String, depth: Int): String? {
            val k = kids(p)
            if (k.contains("encoder_model.ort")) { streamingModel = false; return p }
            if (k.contains("streaming_config.json") && k.contains("encoder.ort")) { streamingModel = true; return p }
            if (depth == 0) return null
            for (n in k) {
                val sub = if (p.isEmpty()) n else "$p/$n"
                search(sub, depth - 1)?.let { return it }
            }
            return null
        }
        return search(modelDir, 3) ?: search("", 4) ?: modelDir
    }

    /** وصف مختصر لمحتوى الـ assets عشان نعرف الملفات الفعلية لو الموديل ناقص. */
    private fun describeAssets(): String {
        val out = ArrayList<String>()
        fun walk(p: String, depth: Int) {
            val k = try { assets.list(p) ?: emptyArray() } catch (e: Exception) { emptyArray() }
            for (n in k) {
                if (out.size >= 14) return
                val sub = if (p.isEmpty()) n else "$p/$n"
                out.add(sub)
                if (depth > 0) walk(sub, depth - 1)
            }
        }
        walk("", 3)
        return if (out.isEmpty()) "(فاضي)" else out.joinToString("  ")
    }

    // ================= شاشة الإعدادات والحقوق =================

    private fun showCredit(v: View) {
        tick(v)
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val dlg = android.app.Dialog(this)
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        dlg.window?.apply {
            setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
            setDimAmount(0.6f)
        }
        val cardBg = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0, 0)).apply { cornerRadius = dpf(34f) }
        val card = FrameLayout(this).apply {
            background = cardBg
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            clipToOutline = true
            elevation = dpf(12f)
        }
        val tile = ZelligeView(this)
        card.addView(tile, FrameLayout.LayoutParams(match, match))

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(26), dp(18), dp(20))
        }
        fun lp(w: Int, h: Int, top: Int) = LinearLayout.LayoutParams(w, h).apply { topMargin = dp(top) }
        fun sectionLabel(t: String) = TextView(this).apply {
            text = t; textSize = 12f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; letterSpacing = 0.05f
        }
        fun divider() = View(this)

        val star = DualStarView(this, 20f)
        box.addView(star, lp(dp(64), dp(64), 0))

        // --- السمات ---
        val themesLabel = sectionLabel("السمات")
        box.addView(themesLabel, lp(wrap, wrap, 14))
        val swatchBgs = ArrayList<GradientDrawable>()
        val swatchNames = ArrayList<TextView>()
        val swatchRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; layoutDirection = View.LAYOUT_DIRECTION_RTL }
        THEMES.forEachIndexed { i, th ->
            val circleBg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(th.dark.mid, th.dark.ac)).apply { shape = GradientDrawable.OVAL }
            val circle = View(this).apply { background = circleBg }
            val nm = TextView(this).apply { text = th.name; textSize = 10.5f; gravity = Gravity.CENTER; maxLines = 1 }
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                isClickable = true
                addView(circle, LinearLayout.LayoutParams(dp(38), dp(38)))
                addView(nm, lp(wrap, wrap, 5))
            }
            item.setOnClickListener {
                tick(it)
                it.scaleX = 0.8f; it.scaleY = 0.8f
                it.animate().scaleX(1f).scaleY(1f).setDuration(380).setInterpolator(OvershootInterpolator(3f)).start()
                setThemeIdx(i)
                repaint()
            }
            swatchBgs.add(circleBg); swatchNames.add(nm)
            swatchRow.addView(item, LinearLayout.LayoutParams(0, wrap, 1f))
        }
        box.addView(swatchRow, lp(match, wrap, 10))

        val div1 = divider()
        box.addView(div1, lp(dp(120), 1, 18))

        // --- عن البرنامج ---
        val aboutLabel = sectionLabel("عن البرنامج")
        box.addView(aboutLabel, lp(wrap, wrap, 16))
        val aboutTv = TextView(this).apply {
            text = "كلام لنص بيحوّل صوتك العربي لنص بدون إنترنت، بموديل Moonshine شغّال على جهازك نفسه.\nاضغط الكرة وتكلّم، أو اختار ملف صوتي.\nالإصدار 1.2"
            textSize = 12.5f
            gravity = Gravity.CENTER
            setLineSpacing(0f, 1.2f)
        }
        box.addView(aboutTv, lp(wrap, wrap, 8))

        val div2 = divider()
        box.addView(div2, lp(dp(120), 1, 18))

        // --- الحقوق (كارت مميز: زخارف + اسم ذهبي بلمعة بتعدّي عليه) ---
        val credBg = GradientDrawable().apply { cornerRadius = dpf(26f) }
        val cred = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = credBg
            setPadding(dp(20), dp(14), dp(20), dp(16))
        }
        val diaBgL = GradientDrawable()
        val diaBgR = GradientDrawable()
        val diaL = View(this).apply { rotation = 45f; background = diaBgL }
        val diaR = View(this).apply { rotation = 45f; background = diaBgR }
        val credLabel = TextView(this).apply { text = "إنشاء وتصميم"; textSize = 13f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER; letterSpacing = 0.08f }
        val credRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(diaL, LinearLayout.LayoutParams(dp(6), dp(6)).apply { marginEnd = dp(10) })
            addView(credLabel, LinearLayout.LayoutParams(wrap, wrap))
            addView(diaR, LinearLayout.LayoutParams(dp(6), dp(6)).apply { marginStart = dp(10) })
        }
        cred.addView(credRow, lp(wrap, wrap, 0))
        val nameTv = TextView(this).apply {
            text = "يوسف فتحي طلعت"
            textSize = 25f
            typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
            gravity = Gravity.CENTER
        }
        cred.addView(nameTv, lp(wrap, wrap, 6))
        val div3 = divider()
        cred.addView(div3, lp(dp(110), 1, 8))
        box.addView(cred, lp(wrap, wrap, 16))

        val closeBg = GradientDrawable().apply { cornerRadius = dpf(24f) }
        val close = TextView(this).apply {
            text = "تمام"; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
            background = closeBg; isClickable = true
            setOnClickListener { tick(it); dlg.dismiss() }
        }
        box.addView(close, lp(dp(130), dp(44), 20))

        var shimmerShader: android.graphics.Shader? = null
        var shimmerW = 1f
        fun lineBg(p: Pal) = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Color.TRANSPARENT, p.gold, Color.TRANSPARENT))
        fun repaint0() {
            val p = palAt(themeT)
            cardBg.colors = intArrayOf(p.mid, p.card)
            cardBg.setStroke(dp(1), p.stroke)
            tile.setTint(p.gold, 22)
            star.color = p.gold
            themesLabel.setTextColor(p.gold); aboutLabel.setTextColor(p.gold)
            aboutTv.setTextColor(p.sub); credLabel.setTextColor(p.gold)
            div1.background = lineBg(p); div2.background = lineBg(p); div3.background = lineBg(p)
            credBg.setColor(androidx.core.graphics.ColorUtils.setAlphaComponent(p.gold, 22))
            credBg.setStroke(dp(1), androidx.core.graphics.ColorUtils.setAlphaComponent(p.gold, 150))
            diaBgL.setColor(p.gold); diaBgR.setColor(p.gold)
            nameTv.setTextColor(p.gold)
            nameTv.setShadowLayer(dpf(12f), 0f, 0f, androidx.core.graphics.ColorUtils.setAlphaComponent(p.gold, 130))
            val sw = nameTv.paint.measureText(nameTv.text.toString()).coerceAtLeast(1f)
            shimmerW = sw
            val hi = androidx.core.graphics.ColorUtils.blendARGB(p.gold, Color.WHITE, 0.8f)
            shimmerShader = android.graphics.LinearGradient(
                0f, 0f, sw * 0.8f, 0f, intArrayOf(p.gold, hi, p.gold), floatArrayOf(0f, 0.5f, 1f),
                android.graphics.Shader.TileMode.MIRROR
            )
            nameTv.paint.shader = shimmerShader
            nameTv.invalidate()
            swatchBgs.forEachIndexed { i, bgd ->
                if (i == themeIdx) bgd.setStroke(dp(3), p.gold) else bgd.setStroke(dp(1), p.stroke)
                swatchNames[i].setTextColor(if (i == themeIdx) p.tx else p.sub)
            }
            closeBg.setColor(p.chip); closeBg.setStroke(dp(1), p.stroke)
            close.setTextColor(p.ac)
        }
        repaintRef = ::repaint0
        repaint0()

        val scroll = ScrollView(this).apply { isVerticalScrollBarEnabled = false; addView(box) }
        card.addView(scroll, FrameLayout.LayoutParams(match, wrap))
        dlg.setContentView(card)
        dlg.window?.setLayout(minOf(dp(330), resources.displayMetrics.widthPixels - dp(24)), wrap)
        dlg.window?.setGravity(Gravity.CENTER)
        val mx = android.graphics.Matrix()
        val shimmer = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2600
            repeatCount = ValueAnimator.INFINITE
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener {
                mx.setTranslate((it.animatedValue as Float) * shimmerW * 1.6f, 0f)
                shimmerShader?.setLocalMatrix(mx)
                nameTv.invalidate()
            }
        }
        dlg.setOnDismissListener { repaintRef = null; shimmer.cancel() }
        card.alpha = 0f; card.scaleX = 0.7f; card.scaleY = 0.7f
        dlg.show()
        shimmer.start()
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(420)
            .setInterpolator(OvershootInterpolator(1.6f)).start()
    }

    private var repaintRef: (() -> Unit)? = null
    private fun repaint() { repaintRef?.invoke() }

    // ================= الثيم =================

    private fun toggleTheme(v: View) {
        tick(v)
        dark = !dark
        prefs.edit().putBoolean("dark", dark).apply()
        sunMoon.animateTo(if (dark) 1f else 0f)
        themeAnim?.cancel()
        themeAnim = ValueAnimator.ofFloat(themeT, if (dark) 0f else 1f).apply {
            duration = 450
            addUpdateListener { applyTheme(it.animatedValue as Float) }
            start()
        }
    }

    private fun palAt(t: Float): Pal = Pal.lerp(THEMES[themeIdx].dark, THEMES[themeIdx].light, t.coerceIn(0f, 1f))

    private fun setThemeIdx(i: Int) {
        if (i == themeIdx) return
        val from = palAt(themeT)
        themeIdx = i
        prefs.edit().putInt("theme", i).apply()
        val to = palAt(themeT)
        themeSwitch?.cancel()
        themeSwitch = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 450
            addUpdateListener { applyTheme(themeT, Pal.lerp(from, to, it.animatedValue as Float)) }
            start()
        }
    }

    private fun applyTheme(t: Float, pal: Pal? = null) {
        themeT = t
        val p = pal ?: palAt(t)
        bg.colors = intArrayOf(p.mid, p.edge)
        topBg.setColor(p.card); topBg.setStroke(dp(1), p.stroke)
        resBg.setColor(p.card); resBg.setStroke(dp(1), p.stroke)
        toggleBg.setColor(p.chip)
        titleTv.setTextColor(p.gold)
        subTv.setTextColor(p.sub)
        sunMoon.sunColor = p.gold
        zellige.setTint(p.gold, (26 + 16 * t).toInt())
        headStar.color = p.gold
        hintStar.color = p.gold
        loadBar.color = p.gold
        status.setTextColor(if (recording) p.dng else p.sub)
        result.setTextColor(p.tx)
        hint.setTextColor(p.sub)
        fileBtn.style(p, false)
        orb.style(p)
        copyBtn.style(p, false)
        clearBtn.style(p, false)
        val light = t > 0.5f
        if (lightBars != light) {
            lightBars = light
            barsCtrl.isAppearanceLightStatusBars = light
            barsCtrl.isAppearanceLightNavigationBars = light
        }
    }

    private fun tick(v: View) { v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY) }

    // ================= التسجيل والتحويل (زي ما هو) =================

    private fun toggleRecord() {
        if (recording) { recording = false; if (fallbackSys) { try { sr?.stopListening() } catch (e: Throwable) {} ; finishSys("خلص ✓") }; return }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startRecording()
        else askMic.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startRecording() {
        if (!ready && fallbackSys) { startSystemRecognition(); return }
        recording = true
        orb.recording = true
        fileBtn.isEnabled = false
        recStart = SystemClock.elapsedRealtime()
        status.text = "بسجّل...  00:00"
        ui.post(timerTick)
        applyTheme(themeT)
        Thread {
            val minBuf = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val rec = AudioRecord(MediaRecorder.AudioSource.MIC, 16000, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, minBuf * 2)
            val bytes = ByteArrayOutputStream()
            val tmp = ByteArray(minBuf)
            rec.startRecording()
            while (recording) {
                val r = rec.read(tmp, 0, tmp.size)
                if (r > 0) {
                    bytes.write(tmp, 0, r)
                    // مستوى الصوت للأنيميشن
                    var sum = 0.0
                    var n = 0
                    var k = 0
                    while (k + 1 < r) {
                        val v = ((tmp[k].toInt() and 0xff) or (tmp[k + 1].toInt() shl 8)).toShort() / 32768.0
                        sum += v * v; n++; k += 2
                    }
                    if (n > 0) orb.level = (sqrt(sum / n) * 7.0).toFloat().coerceIn(0f, 1f)
                }
            }
            rec.stop(); rec.release()
            orb.level = 0f
            val b = bytes.toByteArray()
            val samples = FloatArray(b.size / 2) { i ->
                ((b[2 * i].toInt() and 0xff) or (b[2 * i + 1].toInt() shl 8)).toShort() / 32768f
            }
            runOnUiThread {
                orb.recording = false
                applyTheme(themeT)
            }
            transcribe(samples)
        }.start()
    }

    private fun work(msg: String, load: () -> FloatArray) {
        status.text = msg; loadBar.busy = true; fileBtn.isEnabled = false; orb.isEnabled = false
        Thread {
            try { transcribe(load()) }
            catch (e: Throwable) { runOnUiThread { status.text = "حصل خطأ: ${e.message}"; loadBar.busy = false; fileBtn.isEnabled = true; orb.isEnabled = true } }
        }.start()
    }

    /** بيقطّع الصوت لقطع 20 ثانية ويجمّع النص. */
    private fun transcribe(audio: FloatArray) {
        runOnUiThread { status.text = "بحوّل لنص..."; loadBar.busy = true; orb.isEnabled = false }
        try {
            val chunk = 20 * 16000
            val sb = StringBuilder()
            var i = 0
            while (i < audio.size) {
                val part = audio.copyOfRange(i, minOf(i + chunk, audio.size))
                val t = transcriber.transcribeWithoutStreaming(part, 16000)
                for (line in t.lines) sb.append(line.text).append(' ')
                val partial = sb.toString()
                runOnUiThread { result.text = partial }
                i += chunk
            }
            runOnUiThread { status.text = "خلص ✓" }
        } catch (e: Throwable) {
            runOnUiThread { status.text = "حصل خطأ: ${e.message}" }
        }
        runOnUiThread { loadBar.busy = false; fileBtn.isEnabled = true; orb.isEnabled = true }
    }

    override fun onDestroy() {
        recording = false
        try { sr?.destroy() } catch (e: Throwable) {}
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
